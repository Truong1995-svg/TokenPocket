/*
 * Copyright 2023 Collabora Ltd.
 * SPDX-License-Identifier: MIT
 */

#error Should not use superproject generated config.h to compile libdbus
